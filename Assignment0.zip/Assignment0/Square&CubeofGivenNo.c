#include<stdio.h>
void main(){
	int no=10 ;
	int square,cube;
	square = no*no;
	cube = no*no*no;
	printf("square of no is:%d",square);
	printf("\nCube of no is:%d",cube);
}