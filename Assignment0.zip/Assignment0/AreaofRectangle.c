#include<stdio.h>
void main(){
	float length = 10;
	float width = 2.5;
	float perimeter = 2*(length + width);
	printf("Perimeter of Rectanle is: %f", perimeter);
}