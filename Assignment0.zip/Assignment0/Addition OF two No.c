void main(){
	int a, b, c;
	a = 10, b=30;
	 c= a+b;
	 printf("Addition of Two integers is: %d ",c);
}