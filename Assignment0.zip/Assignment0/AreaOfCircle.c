void main(){
	float r = 2.2;
	float a;
    a= 3.14*r*r;
	printf("Area Of Circle is: %f",a);
}