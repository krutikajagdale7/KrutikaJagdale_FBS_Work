void main(){
	float c, f;
	f =(10.2*9/2)+32;
	printf("Convert Temp from Celcius to Farenhiet : %f",f);
	
}