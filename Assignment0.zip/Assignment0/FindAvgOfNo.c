#include<stdio.h>
void main(){
	int n1=20;
	int n2=10;
	int n3=90;
	int n4=40;
	int n5=15;
	int avg;
	
	avg = n1+n2+n3+n4+n5/5;
	printf("Average of this five num,ber is: %d",avg);
	
	
}