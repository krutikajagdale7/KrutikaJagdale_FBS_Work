#include<stdio.h>
void main(){
	int base =2;
	//float = 2.5
	int height = 12;
	//float = 12;
int area = 1/2*base*height;//formula - 1/2*b*h or 0.5*b*h || 1/2 = 0.5 the we select only 0 for int multiplication thats why the output will get zero
//float area = 1/2*base*height;
	printf("Area of triangle: %d", area);
	
}